package com.example.myrecipe.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myrecipe.R
import com.example.myrecipe.databinding.ActivitySelectIngredientsBinding
import com.example.myrecipe.fragment.SelectIngredientsFragment

class SelectIngredientsActivity : AppCompatActivity() {
    lateinit var binding: ActivitySelectIngredientsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectIngredientsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }
    private fun init(){
        var fragment = SelectIngredientsFragment()
        val transaction = supportFragmentManager.beginTransaction()

        transaction.replace(R.id.frameLayout2,fragment)
        transaction.commit()

        }

    }
