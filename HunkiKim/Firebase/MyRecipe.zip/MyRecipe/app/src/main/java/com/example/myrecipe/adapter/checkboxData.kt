package com.example.myrecipe.adapter

data class checkboxData(var id: Int, var checked: Boolean) {

}