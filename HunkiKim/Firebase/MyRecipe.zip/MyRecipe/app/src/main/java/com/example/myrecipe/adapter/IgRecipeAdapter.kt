package com.example.myrecipe.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.example.myrecipe.R
import com.example.myrecipe.databinding.RowIngredientBinding
import com.example.myrecipe.databinding.RowRecipeBinding

class IgRecipeAdapter(val items:ArrayList<String>):
        RecyclerView.Adapter<IgRecipeAdapter.ViewHolder>()
{
    var IgList:ArrayList<String> = ArrayList()
    inner class ViewHolder(val binding: RowIngredientBinding): RecyclerView.ViewHolder(binding.root){

        init {

        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IgRecipeAdapter.ViewHolder {
        val view = RowIngredientBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: IgRecipeAdapter.ViewHolder, position: Int) {
        holder.binding.apply {
            igtext.text = items[position]
            if(radioButton2.isChecked){
                IgList.add(items[position])
            }
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

}